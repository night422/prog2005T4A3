// controllers/controller.js
const db = require('user_management/db'); 

// Get all categories
exports.getCategories = (req, res) => {
    db.query('SELECT * FROM category', (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
};

// Add a new category
exports.addCategory = (req, res) => {
    const { name } = req.body;
    const query = 'INSERT INTO category (NAME) VALUES (?)';
    db.query(query, [name], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Category added successfully', categoryId: result.insertId });
    });
};

// Update a category
exports.updateCategory = (req, res) => {
    const { id } = req.params;
    const { name } = req.body;
    const query = 'UPDATE category SET NAME = ? WHERE CATEGORY_ID = ?';
    db.query(query, [name, id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Category updated successfully' });
    });
};

// Delete a category
exports.deleteCategory = (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM category WHERE CATEGORY_ID = ?';
    db.query(query, [id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Category deleted successfully' });
    });
};

// --- Donation Management ---

// Get all donations
exports.getDonations = (req, res) => {
    db.query('SELECT * FROM donation', (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
};

// Add a new donation
exports.addDonation = (req, res) => {
    const { date, amount, giver, fundraiserId } = req.body;
    const query = 'INSERT INTO donation (`DATE`, AMOUNT, GIVER, FUNDRAISER_ID) VALUES (?, ?, ?, ?)';
    db.query(query, [date, amount, giver, fundraiserId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Donation added successfully', donationId: result.insertId });
    });
};

// Update a donation
exports.updateDonation = (req, res) => {
    const { id } = req.params;
    const { date, amount, giver, fundraiserId } = req.body;
    const query = 'UPDATE donation SET `DATE` = ?, AMOUNT = ?, GIVER = ?, FUNDRAISER_ID = ? WHERE DONATION_ID = ?';
    db.query(query, [date, amount, giver, fundraiserId, id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Donation updated successfully' });
    });
};

// Delete a donation
exports.deleteDonation = (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM donation WHERE DONATION_ID = ?';
    db.query(query, [id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Donation deleted successfully' });
    });
};

// --- Fundraiser Management ---

// Get all fundraisers
exports.getFundraisers = (req, res) => {
    db.query('SELECT * FROM fundraiser', (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
};

// Add a new fundraiser
exports.addFundraiser = (req, res) => {
    const { organizer, caption, targetFunding, currentFunding, city, active, categoryId } = req.body;
    const query = 'INSERT INTO fundraiser (ORGANIZER, CAPTION, TARGET_FUNDING, CURRENT_FUNDING, CITY, ACTIVE, CATEGORY_ID) VALUES (?, ?, ?, ?, ?, ?, ?)';
    db.query(query, [organizer, caption, targetFunding, currentFunding, city, active, categoryId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Fundraiser added successfully', fundraiserId: result.insertId });
    });
};

// Update a fundraiser
exports.updateFundraiser = (req, res) => {
    const { id } = req.params;
    const { organizer, caption, targetFunding, currentFunding, city, active, categoryId } = req.body;
    const query = 'UPDATE fundraiser SET ORGANIZER = ?, CAPTION = ?, TARGET_FUNDING = ?, CURRENT_FUNDING = ?, CITY = ?, ACTIVE = ?, CATEGORY_ID = ? WHERE FUNDRAISER_ID = ?';
    db.query(query, [organizer, caption, targetFunding, currentFunding, city, active, categoryId, id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Fundraiser updated successfully' });
    });
};

// Delete a fundraiser
exports.deleteFundraiser = (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM fundraiser WHERE FUNDRAISER_ID = ?';
    db.query(query, [id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Fundraiser deleted successfully' });
    });
};
